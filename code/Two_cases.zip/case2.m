%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%    Code for Case Study 2    %%%%%
%%%%%                             %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
clc
%%%%%%%%Network parameters%%%%%%%%
N=6;                                                                       %No. antennas of each RRH
J=3;                                                                       %No. RRHs
K=3;                                                                       %No. CUs
L=1;                                                                       %No. STs
I=360;
P_Tmax=45;                                                                 %Transmit power
R_req=2;
P_req=10^(-12);                                                            %Required echo power
C_Fmax=5.5;
N_b=4;
M=100;
Delta_R=20;
W_F=5*10^(6);
t_min=10^(-7);
psi=30;
c=3*10^(8);
lambda=0.125;
PL_ref=10^(3);
G_t=10;
nu_CU=3;
nu_ST=2;
epsilon=0.1;
D_PT=0;
T=10^(-3);
sigma_n=10^(-10);
loca_RRH=[0 29; 25 -14.5; -25 -14.5]';
G_r=10;
rcs=4;
%%%%%%%%Channel setup of CUs&STs%%%%%%%%
loca_STx=25.*(rand(1,L)-0.5);                                              %Generate the location of the ST
loca_STy=25.*(rand(1,L)-0.5);
loca_ST=[loca_STx loca_STy];
d_ST=zeros(J,1);
for j=1:J                                                                  %Determine the RRH-ST pairing
d_ST(j)=norm(loca_ST-loca_RRH(:,j));
end
[sel_ST,sel_no]=minmat(d_ST);                                              
loca_CUx=100.*(rand(1,K)-0.5*ones(1,K));                                                    %Generate the locations of CUs
loca_CUy=100.*(rand(1,K)-0.5*ones(1,K));
loca_CU=[loca_CUx loca_CUy];
d_CU=zeros(J,K);
hr_k=zeros(N,J,K);
h_k=zeros(J*N,K);
H=zeros(J*N,J*N,K);
for k=1:K                                                                  %Generate fading channels of CUs  
    for j=1:J
d_CU(j,k)=norm(loca_CU(:,k) -loca_RRH(:,j));
PL_CU(j,k) = sqrt((1/PL_ref)*1/(lambda/(4*pi*d_CU(j,k)))^nu_CU);
hr_k(:,j,k) = (1/PL_CU(j,k))*(sqrt(0.5)*randn(N,1,1)+1i*sqrt(0.5)*randn(N,1,1));
    end
h_k(:,k)=reshape([hr_k(:,1,k) hr_k(:,2,k) hr_k(:,3,k)],[1,N*J]);
H(:,:,k)=sqrt(G_t).*h_k(:,k)*h_k(:,k)'.*sqrt(G_r);
end
Pttr=zeros(1,I);                                                           %Calculate the angle for HD-BP
x_0=loca_RRH(1,sel_ST);
y_0=loca_RRH(2,sel_ST);
if(loca_STx>x_0 && loca_STy>y_0)                                           
phi=(180/pi)*atan((loca_STy-y_0)/(loca_STx-x_0));
end
if(loca_STx<x_0 && loca_STy>y_0)
phi=180-(180/pi)*atan((loca_STy-y_0)/(x_0-loca_STx));
end
if(loca_STx<x_0 && loca_STy<y_0)
phi=180+(180/pi)*atan((y_0-loca_STy)/(x_0-loca_STx));
end
if(loca_STx>x_0 && loca_STy<y_0)
phi=360-(180/pi)*atan((y_0-loca_STy)/(loca_STx-x_0));
end
phi=round(phi);                                              
Pttr=[zeros(1,phi-(psi/2)) ones(1,psi) zeros(1,360-phi-(psi/2))];
a=zeros(1,N);                                                              %Generate LoS channel of ST
aa=zeros(I,N);
for n=1:N
a(n)=exp(1i*(lambda/2)*2*pi*(n-1)*sin((phi/180)*2*pi));
end
G=rcs*G_t*(1/PL_ref)*(lambda/(4*pi*d_ST(sel_ST)))^nu_ST.*a'*a*G_r;
%%%%%%%%Algorithm initialization%%%%%%%%
idx1 = 0;
idx2 = 0;
Max_idx = 3;
idx_AO = 1;
Max_idx_AO = 2; 
obj_idx = 0;
delta = 10^(-2);
mu = 10^(-2);
dv = zeros(1,N*J);
xi = 0.00001;
t_p = 2*10^(-6);
zeta = ones(J, K);
zeta_mid = zeta;
time_step = 0.1;
eta = 0.1;
f= [2 1];
%%%%%%%%Optimization problem%%%%%%%%
%while (eta<1)
while(idx_AO<Max_idx_AO || abs(f(1)-f(2))/abs(f(2))>delta)          %Convergence condition
%****Block 1****%

    for idx1 = 1:Max_idx
        obj_idx = obj_idx + 1;
    cvx_begin sdp %quiet
        cvx_precision default
        variable S(N,N) hermitian semidefinite
        variable zeta(J,K)
        variable W(N*J,N*J,K) hermitian semidefinite

        expression trCU
        expression trCUinf
        expression trW(J)
        expression D(I)
        expression D_PT

           for k = 1:K
               trW(k) = trace(W(:,:,k));
           end

        %SCA for binary variable
        penalty = 0;
            for j = 1:J
                for k = 1:K
                    penalty = penalty + (zeta_mid(j,k))^2 + (1-2*zeta_mid(j,k))*zeta(j,k);
                end
            end
        
        minimize ( (1-eta)*T*real(sum(trW(:))) + M*t_p*real(trace(S)) + mu*penalty)

        subject to

        %Constraint C1, achievable rate of CUs
        for k = 1:K
           trCU = 0;
           trCUinf = 0;
           trCU = trCU + real(trace(H(:,:,k)*W(:,:,k)));
           for r = 1:K
              if r ~= k
                 trCUinf = trCUinf + real(trace(H(:,:,k)*W(:,:,r)));
              end
           end
           10^(12)*trCU>= 10^(12)*(trCUinf+sigma_n)*(2^(R_req/(1-eta))-1);
        end

        %Constraint C2, power of sensing echo
        10^(12)*real(trace(G*S*G'))>=10^(12)*P_req;

        %Constraint C3, high-directional beampattern
        for i=1:I
           for n=1:N
               aa(i,n)=exp(1i*(lambda/2)*2*pi*(n-1)*sin((i/180)*pi));
           end
           D(i)=(abs(Pttr(i)-xi*real(aa(i,:)*S*(aa(i,:))')))/I;
           D_PT=D_PT+D(i);
        end
        D_PT<=epsilon;

        %Constraint C4, transmit power allowance for communication
        for k=1:K
        for j=1:J
            dv=[zeros(1,(j-1)*N) ones(1,N) zeros(1,(J-j)*N)];
            DM=diag(dv);
        trace(W(:,:,k)*DM)<=zeta(j,k)*P_Tmax;
        end
        end

        %Constraint C5, transmit power allowance for sensing
        trace(S)<=P_Tmax;

        %Constraint C10a, CU assignment
        zeros(J*K,1) <= vec(zeta) <= ones(J*K,1);

        %Constraint C10b, CU assignment
        for k=1:K
           sum(zeta(:,k))>=1;
        end

        S == hermitian_semidefinite(N);
        for k=1:K
           W(:,:,k) == hermitian_semidefinite(N*J);
        end
    cvx_end

    if strcmp(cvx_status, 'Infeasible') == 1
       continue
    end

    zeta_mid = zeta;
    zeta
        obj(obj_idx) = (1-eta)*T*real(sum(trW(:))) + M*t_p*real(trace(S)) + mu*penalty;           %function value storage
        f(1) = (1-eta)*T*real(sum(trW(:))) + M*t_p*real(trace(S))                               %for monotonicity check
    end


zeta = zeros(J, K);
zeta_mid=zeta;

%****Block 2****%
 for idx2 = 1:Max_idx
    obj_idx = obj_idx + 1;
    cvx_begin %quiet
        variable t_p
        variable xi
        variable zeta(J,K)
        variable W(N*J,N*J,K) hermitian semidefinite
        %variable eta
        expression trCU
        expression trCUinf
        expression trW(J)
        expression D(I)
        expression D_PT
        
        %SCA for binary variable
        penalty=0;
        for j = 1:J
           for k = 1:K
              penalty = penalty + (zeta_mid(j,k))^2 + (1-2*zeta_mid(j,k))*zeta(j,k);
           end
        end
           
        
        for k = 1:K
            trW(k) = trace(W(:,:,k));
        end

        minimize ( (1-eta)*T*real(sum(trW(:))) + M*t_p*real(trace(S)) + mu*penalty)

        subject to

        %Constraint C1, achievable rate of CUs
        for k = 1:K
           trCU = 0;
           trCUinf = 0;
           trCU = trCU + real(trace(H(:,:,k)*W(:,:,k)));
           for r = 1:K
              if r ~= k
                 trCUinf = trCUinf + real(trace(H(:,:,k)*W(:,:,r)));
              end
           end
           10^(12)*trCU>= 10^(12)*(trCUinf+sigma_n)*(2^(R_req/(1-eta))-1);
        end

        %Constraint C3, high-directional beampattern
        for i=1:I
           for n=1:N
               aa(i,n)=exp(1i*(lambda/2)*2*pi*(n-1)*sin((i/180)*pi));
           end
           D(i)=abs(Pttr(i)-xi*aa(i,:)*S*(aa(i,:))');
           D_PT=D_PT+D(i);
        end
        D_PT/I<=epsilon;

        %Constraint C4, transmit power allowance for communication
        for k=1:K
           for j=1:J
               dv=[zeros(1,(j-1)*N) ones(1,N) zeros(1,(J-j)*N)];
               DM=diag(dv);
               trace(W(:,:,k)*DM)<=zeta(j,k)*P_Tmax;
           end
        end

        %Constraint C6, fronhaul link capacity for communication
        for j=1:J
            sum(zeta(j,:))*R_req<=(1-eta)*C_Fmax;
        end

        %Constraint C7, fronhaul link capacity for sensing
        (c*(eta*T/M-t_p)/2-(c*t_p)/2)*N_b<=Delta_R*W_F*(eta*T/M-t_p)*C_Fmax;

        %Constraint C8, pulse time limitation
        10^(6)*t_min<=10^(6)*t_p;

        %Constraint C9, sensing distance interval
        c*(eta*T/M-t_p)/2>=d_ST(sel_ST)>=(c*t_p)/2;

        %Constraint C10a
        zeros(J*K,1) <= vec(zeta) <= ones(J*K,1);

        %Constraint C10b
        for k=1:K
           sum(zeta(:,k))>=1;
        end

        %Constraint C11, if we also want to optimize time allocation
        %0<eta<1;

        for k=1:K
           W(:,:,k) == hermitian_semidefinite(N*J);
        end
    cvx_end
        zeta_mid = zeta;
        zeta
        obj(obj_idx) = (1-eta)*T*real(sum(trW(:))) + M*t_p*real(trace(S)) + mu*penalty;    %function value storage
        f(2) = (1-eta)*T*real(sum(trW(:))) + M*t_p*real(trace(S))                      %for monotonicity check
 end
 idx_AO = idx_AO + 1;
end
%eta = eta + time_step;
%end 