clc
clear
clear all

%% system setup
N = 8; %antenna number
ref_pathloss = 10^4; % reference pathloss at 1m, 40dB

BS_coord = [[0,100];[100,0];[0,-100];[-100,0]]; % position of BSs
[BS_num,~] = size(BS_coord);

P = 45*ones(BS_num,1); % power consumption

sigma_c = sqrt(10^-10); % noise at CU
sigma_r = sqrt(10^-9); % noise at sensing receiver

epsilon = 1; % QoS of CRB
T = 1024; % time length for sensing
mu = 3000; % penalty factor

CU_num = 5; % CU numbers
Gamma = 10^0.8*ones(CU_num,1); % SINR requirement of CUs

%% generate position of the sensing target
distance = 150*rand(1);
theta = 2*pi*rand(1);
ST_coord = zeros(1,2);
ST_coord(1) = distance*cos(theta);
ST_coord(2) = distance*sin(theta);

%% generate position of the communication users
CU_coord = zeros(CU_num,2);
for i = 1:CU_num
    distance = 150*rand(1);
    theta = 2*pi*rand(1);
    CU_coord(i,1) = distance*cos(theta);
    CU_coord(i,2) = distance*sin(theta);
end

%%  target response matrix
d_ST = zeros(1,BS_num);
for i = 1:BS_num
    d_ST(i) = sqrt((ST_coord(1)-BS_coord(i,1))^2+(ST_coord(2)-BS_coord(i,2))^2);

    sin_theta(i) = (ST_coord(2)-BS_coord(i,2))/d_ST(i);
    dsin_x(i) = -(ST_coord(1)-BS_coord(i,1))*(ST_coord(2)-BS_coord(i,2))/d_ST(i)^3;
    dsin_y(i) = (ST_coord(1)-BS_coord(i,1))^2/d_ST(i)^3;

    array(:,i) = exp(-1j*pi*(0:N-1)'*sin_theta(i))/sqrt(ref_pathloss);
    darray_x(:,i) = -1j*pi*(0:N-1)'.*array(:,i)*dsin_x(i);
    darray_y(:,i) = -1j*pi*(0:N-1)'.*array(:,i)*dsin_y(i);
end

G = zeros(N, N, BS_num, BS_num);
G_x = zeros(N, N, BS_num, BS_num);
G_y = zeros(N, N, BS_num, BS_num);

for i = 1:BS_num
    for j = 1:BS_num
        G(:,:,i,j) = array(:,i)*array(:,j)';
        G_x(:,:,i,j) = darray_x(:,i)*array(:,j)' + array(:,i)*darray_x(:,j)';
        G_y(:,:,i,j) = darray_y(:,i)*array(:,j)' + array(:,i)*darray_y(:,j)';
    end
end

%% communication channel
h = zeros(N, 1, BS_num, CU_num);
H = zeros(N, N, BS_num, CU_num);
d_CU = zeros(BS_num, CU_num);
for i = 1:BS_num
    for j = 1:CU_num
        d_CU(i,j) = sqrt((CU_coord(j,1)-BS_coord(i,1))^2+(CU_coord(j,2)-BS_coord(i,2))^2);
        h(:,1,i,j) = (randn(N,1) + 1j*randn(N,1))/sqrt(2);
        H(:,:,i,j) = 1/(d_CU(i,j))^3/ref_pathloss*h(:,1,i,j)*h(:,1,i,j)';
    end
end

%% Association variables
A = zeros(BS_num, CU_num);
At = A;

b = ones(BS_num, 1);
bt = b;

%% Initialization
R = zeros(N, N, BS_num);
for s = 1:BS_num
    distance = (randn(N,1) + 1j*randn(N,1))/sqrt(2);
    R(:,:,s) = distance*distance'/2;
end

W = zeros(N, N, BS_num, CU_num);
for s = 1:BS_num
    for k = 1:CU_num
        w = (randn(N,1) + 1j*randn(N,1))/sqrt(2);
        W(:,:,s,k) = w*w'/2;
    end
end

J = zeros(2,2);

aW = W;

Pb = 0;

f = 0;
iter_num = 20;
for iter_idx = 1:iter_num
    
    ft = f;
    fA = 0;
    %% update A
    for iteration_A = 1:10
        fAt = fA;
        cvx_begin sdp
            cvx_solver mosek
            cvx_precision default
            variable W(N,N,BS_num,CU_num) hermitian
            variable aW(N,N,BS_num,CU_num) hermitian
            variable R(N,N,BS_num) hermitian
            variable J(2, 2) hermitian
            variable A(BS_num, CU_num)

            expression Panelty
            expression trR(BS_num, 1);
            expression trW(BS_num, CU_num);
            expression traW(BS_num, CU_num);
            expression trHaW
            expression trHaW1
            expression trHR
            expression M(2*BS_num, 2*BS_num, BS_num);
            expression M_11(2, 2);
            expression M1(N, N)
            expression M2(N, N)
            expression Fx1(BS_num)
            expression Fx2(BS_num)
            expression Fx3(BS_num)
            expression Fxx_mid(2,2,BS_num)

            for i = 1:BS_num
                trR(i) = trace(R(:,:,i));
            end

            for i = 1:BS_num
                for j = 1:CU_num
                    trW(i,j) = trace(W(:,:,i,j));
                end
            end

            for i = 1:BS_num
                for j = 1:CU_num
                    traW(i,j) = trace(aW(:,:,i,j));
                end
            end

            Panelty = 0;
            for s = 1:BS_num
                for k = 1:CU_num
                    Panelty = Panelty + (1-2*At(s,k))*A(s,k) + At(s,k)^2;
                end
            end

            minimize ( real(sum(traW(:)) + b.'*trR) + mu*Panelty);

            subject to
                for s = 1:BS_num
                    for k = 1:CU_num
                        W(:,:,s,k) ==  hermitian_semidefinite(N);
                    end
                end

                for s = 1:BS_num
                    for k = 1:CU_num
                        aW(:,:,s,k) ==  hermitian_semidefinite(N);
                    end
                end

                for s = 1:BS_num
                    R(:,:,s) ==  hermitian_semidefinite(N);
                end

                J == hermitian_semidefinite(2);

    %           power constraint
                for s = 1:BS_num
                    real(sum(traW(s,:)) + b(s)*trR(s)) <= P(s);
                end

                % SINR constraint
                for k = 1:CU_num
                    trHaW = 0;
                    trHaW1 = 0;
                    trHR = 0;
                    for s = 1:BS_num
                        trHaW = trHaW + trace(H(:,:,s,k)*aW(:,:,s,k));
                        trHR = trHR + b(s)*trace(H(:,:,s,k)*R(:,:,s));
                        for k1 = 1:CU_num
                            if k1 ~= k
                                trHaW1 = trHaW1 + trace(H(:,:,s,k)*aW(:,:,s,k1));
                            end
                        end
                    end
                    real(1/Gamma(k)*trHaW - trHaW1 - trHR)*1e9 >= sigma_c^2*1e9;
                end

                % CRB Fx1
                for s = 1:BS_num
                    M2 = zeros(N, N);
                    for s1 = 1:BS_num
                        if s1~= s
                            M1 = zeros(N, N);
                            for k = 1:CU_num
                                M1 = M1 + aW(:,:,s1,k);
                            end
                            M1 = M1 + R(:,:,s1);
                            M2 = M2 + G_x(:,:,s,s1)*M1*G_x(:,:,s,s1)';
                        end
                    end
                    Fx1(s) = 2*T*real(trace(M2))/sigma_r^2;
                end

                % CRB Fx2
                for s = 1:BS_num
                    M2 = zeros(N, N);
                    for s1 = 1:BS_num
                        if s1~= s
                            M1 = zeros(N, N);
                            for k = 1:CU_num
                                M1 = M1 + aW(:,:,s1,k);
                            end
                            M1 = M1 + R(:,:,s1);
                            M2 = M2 + G_y(:,:,s,s1)*M1*G_x(:,:,s,s1)';
                        end
                    end
                    Fx2(s) = 2*T*real(trace(M2))/sigma_r^2;
                end

                % CRB Fx3
                for s = 1:BS_num
                    M2 = zeros(N, N);
                    for s1 = 1:BS_num
                        if s1~= s
                            M1 = zeros(N, N);
                            for k = 1:CU_num
                                M1 = M1 + aW(:,:,s1,k);
                            end
                            M1 = M1 + R(:,:,s1);
                            M2 = M2 + G_y(:,:,s,s1)*M1*G_y(:,:,s,s1)';
                        end
                    end
                    Fx3(s) = 2*T*real(trace(M2))/sigma_r^2;
                end

                % CRB constraint
                M_11 = zeros(2, 2);
                for s = 1:BS_num
                    Fxx_mid(:,:,s) = [Fx1(s), Fx2(s); Fx2(s), Fx3(s)];
                    M_11 = M_11 + (1-b(s))*(Fxx_mid(:,:,s) - J);
                end
                M_11*1e-8 >= 0;

    %               CRB
                trace_inv(J) <= epsilon;

                % binary
                for k = 1:CU_num
                    sum(A(:,k)) == 1;
                end
  
                % Rx does not transmit downlink information
                for s = 1:BS_num
                    for k = 1:CU_num
                        b(s) >= A(s,k); 
                    end
                end

                0 <= vec(A) <= ones(BS_num*CU_num,1);

                % big-M
                for s = 1:BS_num
                    for k = 1:CU_num
                        aW(:,:,s,k) <= A(s,k)*P(s)*eye(N);
                        aW(:,:,s,k) >= W(:,:,s,k) - (1-A(s,k))*P(s)*eye(N);
                        aW(:,:,s,k) <= W(:,:,s,k);
                        aW(:,:,s,k) >= 0;                    
                    end
                end
        cvx_end

        At = A;
        
        fA = real(sum(traW(:)) + b.'*trR) + mu*Panelty;
        if abs(fAt - fA) <= 1e-2
            break
        end
        
    end
        
    %% update b
    fb = 0;
    for iteration_b = 1:10
        fbt = fb;
        cvx_begin sdp
            cvx_solver mosek
            variable b(BS_num,1)
            variable W(N,N,BS_num,CU_num) hermitian
            variable R(N,N,BS_num) hermitian
            variable J(2, 2) hermitian
            variable bW(N,N,BS_num, CU_num, BS_num) hermitian
            variable bR(N,N,BS_num,BS_num) hermitian
            variable bJJ(2, 2,BS_num) hermitian
            
            expression Pb
            expression trR(BS_num, 1)
            expression trW(BS_num, CU_num)
            expression traW(BS_num, CU_num);
            expression trbR(N,N,BS_num)
            expression trHW
            expression trHW1
            expression trHR
            expression M_11(2, 2);
            expression M1(N, N)
            expression M2(N, N)
            expression Fx1(BS_num)
            expression Fx2(BS_num)
            expression Fx3(BS_num)
            expression Fxx_mid(2,2,BS_num)
            
            for i = 1:BS_num
                trR(i) = trace(R(:,:,i));
            end

            for i = 1:BS_num
                for j = 1:CU_num
                    trW(i,j) = trace(W(:,:,i,j));
                end
            end

            for s = 1:BS_num
                for k = 1:CU_num
                    traW(s,k) = trace(A(s,k)*W(:,:,s,k));
                end
            end
            
            for s = 1:BS_num
                trbR(s) = trace(bR(:,:,s,s));
            end
            
            Pb = 0;
            for s = 1:BS_num
                Pb = Pb + (1-2*bt(s))*b(s) + bt(s)^2;
            end
            minimize ( real(sum(traW(:)))+ real(sum(trbR(:))) + mu*Pb);

            subject to
    %                 power constraint
                for s = 1:BS_num
                    A(s,:)*trW(s,:).' + trbR(s) <= P(s);
                end

    %                 SINR constraint
                for k = 1:CU_num
                    trHW = 0;
                    trHW1 = 0;
                    trHR = 0;
                    for s = 1:BS_num
                        trHW = trHW + A(s,k)*trace(H(:,:,s,k)*W(:,:,s,k));
                        trHR = trHR + trace(H(:,:,s,k)*bR(:,:,s,s));
                        for k1 = 1:CU_num
                            if k1 ~= k
                                trHW1 = trHW1 + A(s,k1)*trace(H(:,:,s,k)*W(:,:,s,k1));
                            end
                        end
                    end
                    real(1/Gamma(k)*trHW - trHW1 - trHR)*1e8 >= sigma_c^2*1e8;
                end

                % CRB Fx1
                for s = 1:BS_num
                    M2 = zeros(N, N);
                    for s1 = 1:BS_num
                        if s1~= s
                            M1 = zeros(N, N);
                            for k = 1:CU_num
                                M1 = M1 +  A(s1,k)*(W(:,:,s1,k) - bW(:,:,s1,k,s));
                            end
                            M1 = M1 + (R(:,:,s1) - bR(:,:,s1,s));
                            M2 = M2 + G_x(:,:,s,s1)*M1*G_x(:,:,s,s1)';
                        end
                    end
                    Fx1(s) = 2*T*real(trace(M2))/sigma_r^2;
                end
                
                % CRB Fx2
                for s = 1:BS_num
                    M2 = zeros(N, N);
                    for s1 = 1:BS_num
                        if s1~= s
                            M1 = zeros(N, N);
                            for k = 1:CU_num
                                M1 = M1 +  A(s1,k)*(W(:,:,s1,k) - bW(:,:,s1,k,s));
                            end
                            M1 = M1 + (R(:,:,s1) - bR(:,:,s1,s));
                            M2 = M2 + G_y(:,:,s,s1)*M1*G_x(:,:,s,s1)';
                        end
                    end
                    Fx2(s) = 2*T*real(trace(M2))/sigma_r^2;
                end
                
                % CRB Fx2
                for s = 1:BS_num
                    M2 = zeros(N, N);
                    for s1 = 1:BS_num
                        if s1~= s
                            M1 = zeros(N, N);
                            for k = 1:CU_num
                                M1 = M1 +  A(s1,k)*(W(:,:,s1,k) - bW(:,:,s1,k,s));
                            end
                            M1 = M1 + (R(:,:,s1) - bR(:,:,s1,s));
                            M2 = M2 + G_y(:,:,s,s1)*M1*G_y(:,:,s,s1)';
                        end
                    end
                    Fx3(s) = 2*T*real(trace(M2))/sigma_r^2;
                end
                
                % CRB
                M_11 = zeros(2, 2);
                for s = 1:BS_num
                    Fxx_mid(:,:,s) = [Fx1(s), Fx2(s); Fx2(s), Fx3(s)];
                    M_11 = M_11 + Fxx_mid(:,:,s) - (J - bJJ(:,:,s));
                end
                M_11*1e-6 >= 0;

    %               CRB
                trace_inv(J) <= epsilon;
                
                % select one receiver
                sum(ones(BS_num,1)-b) == 1;

                % Rx does not transmit the downlink information
                for s = 1:BS_num
                    for k = 1:CU_num
                        b(s) >= A(s,k);
                    end
                end

                for s = 1:BS_num
                    1e-5 <= b(s)  <= 1;
                end
                
                % big-M
                for s1 = 1:BS_num
                    for s = 1:BS_num
                        for k = 1:CU_num
                            bW(:,:,s,k,s1) <= b(s1)*P(s)*eye(N);
                            bW(:,:,s,k,s1) >= W(:,:,s,k) - (1-b(s1))*P(s)*eye(N);
                            bW(:,:,s,k,s1) <= W(:,:,s,k);
                            bW(:,:,s,k,s1) >= 0;                    
                        end
                    end
                end
                
                for s1 = 1:BS_num
                    for s = 1:BS_num
                        bR(:,:,s,s1) <= b(s1)*P(s)*eye(N);
                        bR(:,:,s,s1) >= R(:,:,s) - (1-b(s1))*P(s)*eye(N);
                        bR(:,:,s,s1) <= R(:,:,s);
                        bR(:,:,s,s1) >= 0;                    
                    end
                end
                
                for s1 = 1:BS_num
                    bJJ(:,:,s1) <= b(s1)*P(s)*eye(2);
                    bJJ(:,:,s1) >= J - (1-b(s1))*P(s)*eye(2);
                    bJJ(:,:,s1) <= J;
                    bJJ(:,:,s1) >= 0;
                end
                
        cvx_end
        
        bt = b;
        
        fb = real(sum(traW(:)))+ real(sum(trbR(:))) + mu*Pb;
        if abs(fbt-fb) <1e-2
            break
        end
            
    end
    
    f = real(sum(traW(:)))+ real(sum(trbR(:))) + mu*Pb;
    if abs(f-ft) <= 1e-2
        break
    end
    
end